class Destination {
  final int id;
  final String title;
  final String location;
  final String imageUrl;
  final String description;
  final String? distance;

  Destination({
    required this.id,
    required this.title,
    required this.location,
    required this.imageUrl,
    required this.description,
    this.distance,
  });

  factory Destination.fromJson(Map<String, dynamic> json) {
    return Destination(
      id: int.parse(json['id'].toString()),
      title: json['title'],
      location: json['location'],
      imageUrl: json['image_url'], // dari API CI3
      description: json['description'],
    );
  }

  Destination copyWith({String? distance}) {
    return Destination(
      id: id,
      title: title,
      location: location,
      imageUrl: imageUrl,
      description: description,
      distance: distance ?? this.distance,
    );
  }
}
